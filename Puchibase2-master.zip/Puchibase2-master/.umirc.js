
export default {
  hashHistory: false,
  plugins: [
    'umi-plugin-dva',
  ],
}
